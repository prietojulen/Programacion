package Excepciones;

public class DatoNoValidoException extends Exception{
    
}
