package Excepciones;

public class OpcionNoValida extends Exception{
    
}
