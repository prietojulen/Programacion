
package ejerciciounov3;

import java.util.Scanner;

public class EjercicioUnoV3 {

    public static void main(String[] args) {
        Scanner sc;
        sc = new Scanner(System.in);

        System.out.println("Teclea un mensaje");
        String mensaje = sc.nextLine();
        
        System.out.println(mensaje);
    }
    
}
