
package ejerciciouno;

public class EjercicioUno {

    public static void main(String[] args) {
        // Entrada
        String mensaje;
        mensaje= javax.swing.JOptionPane.showInputDialog("Teclea un mensaje");
        // Salida
        javax.swing.JOptionPane.showMessageDialog(null, mensaje);
    }
}
